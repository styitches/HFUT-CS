

package com.B;
import com.A.*;
public class B {
B(int x, int y){
super(x, y);
}
public static void main(String[] args) {
A first = new A(1, 1);
}
}