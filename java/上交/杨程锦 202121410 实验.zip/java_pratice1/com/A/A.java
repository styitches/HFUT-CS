
package com.A;
public class A {
int x, y;
public A(int x, int y){
this.x = x;
this.y = y;
System.out.println("实例化A:"+x+y);
}
}